# sohas weapon detection > 2022-08-12 2:10pm
https://universe.roboflow.com/object-detection/sohas-weapon-detection-al1by

Provided by Roboflow
License: Public Domain

