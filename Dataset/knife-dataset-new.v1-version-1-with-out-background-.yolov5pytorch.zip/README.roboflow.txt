
knife-dataset-new - v1 version-1-with out background-
==============================

This dataset was exported via roboflow.ai on May 25, 2022 at 9:27 AM GMT

It includes 4075 images.
Knife are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


